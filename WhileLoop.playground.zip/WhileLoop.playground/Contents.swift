//: Playground - noun: a place where people can play

import Foundation

let tryToGet = Int(arc4random_uniform(10))
var got = Int(arc4random_uniform(10))
var play = "fat"
while play.lowercased() == "fat" {
    got = Int(arc4random_uniform(10))
    print("You got \(got)")

    if got != tryToGet{
        print("Ha you're bad")
        got = Int(arc4random_uniform(10))
    }
    else{
        print("YOU TOOK TOO LONG")
    }
    print("Play again? (fat)")
    play = readLine(strippingNewline: true)!
}
